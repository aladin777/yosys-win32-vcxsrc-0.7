namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys (Version Information Unavailable)"; }
